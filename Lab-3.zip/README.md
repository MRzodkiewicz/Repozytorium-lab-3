# Lab-3

## Kompilacja
```bash
gcc src/beaufort.c -o beaufort -Wall
gcc src/bmi.c -o bmi -Wall
```

## Uruchomienie
```bash
./beaufort
./bmi
```
