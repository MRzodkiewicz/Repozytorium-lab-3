#include <stdio.h>

int main() {
    float v_ms, kn;
    int B;
    printf("Podaj predkosc wiatru (m/s): ");
    scanf("%f", &v_ms);

    kn = v_ms * 1.94384;

    if (kn < 1) B = 0;
    else if (kn <= 3) B = 1;
    else if (kn <= 6) B = 2;
    else if (kn <= 10) B = 3;
    else if (kn <= 16) B = 4;
    else if (kn <= 21) B = 5;
    else if (kn <= 27) B = 6;
    else if (kn <= 33) B = 7;
    else if (kn <= 40) B = 8;
    else if (kn <= 47) B = 9;
    else if (kn <= 55) B = 10;
    else if (kn <= 63) B = 11;
    else B = 12;

    printf("Predkosc: %.2f m/s = %.2f kn\n", v_ms, kn);
    printf("Sila wiatru w skali Beauforta: %d\n", B);

    return 0;
}
