#include <stdio.h>

int main() {
    float kg, m, bmi;
    printf("Podaj mase (kg): ");
    scanf("%f", &kg);
    printf("Podaj wzrost (m): ");
    scanf("%f", &m);

    bmi = kg / (m * m);
    printf("BMI = %.1f\n", bmi);

    if (bmi < 18.5)
        printf("Niedowaga\n");
    else if (bmi < 25)
        printf("Prawidlowa\n");
    else if (bmi < 30)
        printf("Nadwaga\n");
    else
        printf("Otylosc\n");

    return 0;
}
